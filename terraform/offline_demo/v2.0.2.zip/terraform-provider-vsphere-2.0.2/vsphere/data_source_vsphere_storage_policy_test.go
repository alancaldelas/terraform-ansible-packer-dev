package vsphere

// Storage policy resource is needed.
